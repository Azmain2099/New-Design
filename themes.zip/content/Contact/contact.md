---
title: "Contact"
email: "amit@gmail.com"
phone: "(+880) 1762988707"
address: "Thana stand, Savar, Dhaka"
twitter_handle: "azmain12345"
contact_card: "/images/demo_contact_vcard.png"
---

# Contact Information

**Email**:  
[fayekazmain6@gmail.com](mailto:fayekazmain6@gmail.com)

**Phone**:  
[(+880) 1762988707]
(tel:(+880) 123456789)

**Address**:  
[Thana Stand, Savar, Dhaka](https://maps.google.com/?q=Thana+Stand,+Savar,+Dhaka)

**Twitter**:  
[Follow on Twitter](https://twitter.com/azmain12345)

---
